"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2021-10-01"
------------------------------------------------------------------------
"""

from Queue_array import Queue
from utilities import queue_to_array

q = Queue()
l = [11, 22, 33, 44]
target = []

for i in l:
    q.insert(i)
    
for i in q:
    print(i)
    
ans = queue_to_array(q, target)

print("*"*60)
print(ans)


"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2021-10-01"
------------------------------------------------------------------------
"""

from Priority_Queue_array import Priority_Queue
from utilities import array_to_pq

q = Priority_Queue()
t = Priority_Queue()
l = [22, 33, 44, 11, 55]
target = []

for i in l:
    q.insert(i)
    
for i in q:
    print(i)
    
ans = array_to_pq(t, l)

print("*"*60)
for i in ans:
    print(i)


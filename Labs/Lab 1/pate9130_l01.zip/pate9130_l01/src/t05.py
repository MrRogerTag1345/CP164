"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2021-09-15"
------------------------------------------------------------------------
"""

from Movie_utilities import get_movie

ans = get_movie()

print(ans)

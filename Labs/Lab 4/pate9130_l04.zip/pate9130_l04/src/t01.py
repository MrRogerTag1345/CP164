"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2021-02-09"
------------------------------------------------------------------------
"""

from List_array import List
from Movie import Movie

movie = Movie('Juno', 2007, None, None, None)

print(movie)

l = List()
temp = [[], [0, 1], 1, 2, 3, 4]
for i in temp:
    l.append(i)
    
for i in l:
    print(i)

val = l.remove([0])

for i in l:
    print(i)
    
print("Val: {}".format(val))

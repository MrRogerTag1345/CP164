"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2021-09-16"
------------------------------------------------------------------------
"""

from functions import is_palindrome

s = "LEveL"

print("{}".format(s))
print("{}".format(is_palindrome(s)))

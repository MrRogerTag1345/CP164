"""
------------------------------------------------------------------------
t03.py

------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2021-09-16"
------------------------------------------------------------------------
"""

# Import.
from functions import clean_list

# Predetermined List
values = [1, 2, 0, 1, 4, 1, 1, 2, 2, 5, 4, 3, 1, 3, 3, 4, 2, 4, 3, 1, 3, 0, 3, 0, 0]

# Send list to function.
clean_list(values)
print("{}".format(values))
